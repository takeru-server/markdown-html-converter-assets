// これは prettier の設定ファイルです
module.exports = {
		// タブを使用するかどうか（true: タブを使用、false: スペースを使用）
		useTabs: true,
		// タブの幅
		tabWidth: 4,
		// セミコロンを付けるかどうか（true: 付ける、false: 付けない）
		semi: true,
		// シングルコーテーションを使用するかどうか（true: 使用する、false: 使用しない）
		singleQuote: true,
		// Vue ファイルの script と style タグ内のインデントを調整するかどうか
		vueIndentScriptAndStyle: true,
		// prittierのプラグイン「prettier-plugin-organize-imports」を使用する　このプラグインの効果：importの順番を最適化してくれる上に、不要なインポートを削除してくれる
		plugins: ['prettier-plugin-organize-imports'],
};
