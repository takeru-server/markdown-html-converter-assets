@echo off
setlocal EnableDelayedExpansion

:: コマンドプロンプトの文字コードをUTF-8に変更
chcp 65001

set "inputMarkdown=%~1"
set "outputHtml=%~dpn1.html"
set "tempFile=%~dpn1.tmp.html"

:: --self-contained を --embed-resources --standalone に変更
:: タイトルを動的に取得
pandoc -f markdown -t html5 "%inputMarkdown%" -s --embed-resources --standalone -c "%~dp0github-markdown.css" -o "%outputHtml%" --metadata title="%~n1"

REM del_start_2024年8月22日_Ver.2.0
REM REM :: 絶対パスを取得 
REM REM set "cssPath=%~dp0gemini-style.css"
REM REM set "jsPath=%~dp0copy-button.js"
REM 
REM :: GitHubからCSSとJSを取得	参考：https://qiita.com/ryome/items/6f4d4a2a8996190a18d8
REM set "cssPath=https://takeru-server.github.io/zero-knowledge-proof/css/gemini-style.css"
REM set "jsPath=https://takeru-server.github.io/zero-knowledge-proof/js/copy-button.js"
REM 
REM :: jQuery CDNのURL
REM set "jqueryCdn=https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"
REM 
REM :: コピーボタンを追加するJavaScriptコード (改行とインデントを追加)
REM REM mod_start_2024年6月27日
REM REM set "copyButtonJs="
REM REM set "copyButtonJs=!copyButtonJs!^<script^>"
REM REM set "copyButtonJs=!copyButtonJs!$(document).ready(function() {"
REM REM set "copyButtonJs=!copyButtonJs!  $('pre code.sourceCode').each(function() {"
REM REM set "copyButtonJs=!copyButtonJs!    const copyButton = $('^<button class=\"copy-button\"^>コピー^</button^>');"
REM REM set "copyButtonJs=!copyButtonJs!    copyButton.on('click', function() {"
REM REM set "copyButtonJs=!copyButtonJs!      const codeBlock = $(this).parent().find('code');"
REM REM set "copyButtonJs=!copyButtonJs!      const tempTextArea = $('^<textarea^>');"
REM REM set "copyButtonJs=!copyButtonJs!      $('body').append(tempTextArea);"
REM REM set "copyButtonJs=!copyButtonJs!      tempTextArea.val(codeBlock.text()).select();"
REM REM set "copyButtonJs=!copyButtonJs!      document.execCommand('copy');"
REM REM set "copyButtonJs=!copyButtonJs!      tempTextArea.remove();"
REM REM set "copyButtonJs=!copyButtonJs!      $(this).text('コピー完了！');"
REM REM set "copyButtonJs=!copyButtonJs!      setTimeout(function() {"
REM REM set "copyButtonJs=!copyButtonJs!        copyButton.text('コピー');"
REM REM set "copyButtonJs=!copyButtonJs!      }, 1500);"
REM REM set "copyButtonJs=!copyButtonJs!    });"
REM REM set "copyButtonJs=!copyButtonJs!    $(this).parent().prepend(copyButton);"
REM REM set "copyButtonJs=!copyButtonJs!  });"
REM REM set "copyButtonJs=!copyButtonJs!});"
REM REM set "copyButtonJs=!copyButtonJs!^</script^>"
REM 
REM 
REM REM 改行コマンドを変数に格納する	参考：https://it-engineer-info.com/language/batch/6481/
REM SET LF=^
REM 
REM 
REM 
REM REM インデントを付けて出力するように修正
REM set "copyButtonJs="
REM set "copyButtonJs=!copyButtonJs!!LF!^	<script^>"
REM set "copyButtonJs=!copyButtonJs!!LF!		$(document).ready(function() {"
REM set "copyButtonJs=!copyButtonJs!!LF!			$('pre code.sourceCode').each(function() {"
REM set "copyButtonJs=!copyButtonJs!!LF!				const copyButton = $('^<button class="copy-button"^>コピー^</button^>');"
REM set "copyButtonJs=!copyButtonJs!!LF!				copyButton.on('click', function() {"
REM set "copyButtonJs=!copyButtonJs!!LF!					const codeBlock = $(this).parent().find('code');"
REM set "copyButtonJs=!copyButtonJs!!LF!					const tempTextArea = $('^<textarea^>');"
REM set "copyButtonJs=!copyButtonJs!!LF!					$('body').append(tempTextArea);"
REM set "copyButtonJs=!copyButtonJs!!LF!					tempTextArea.val(codeBlock.text()).select();"
REM set "copyButtonJs=!copyButtonJs!!LF!					document.execCommand('copy');"
REM set "copyButtonJs=!copyButtonJs!!LF!					tempTextArea.remove();"
REM set "copyButtonJs=!copyButtonJs!!LF!					$(this).text('コピー完了！');"
REM set "copyButtonJs=!copyButtonJs!!LF!					setTimeout(function() {"
REM set "copyButtonJs=!copyButtonJs!!LF!						copyButton.text('コピー');"
REM set "copyButtonJs=!copyButtonJs!!LF!					}, 1500);"
REM set "copyButtonJs=!copyButtonJs!!LF!				});"
REM set "copyButtonJs=!copyButtonJs!!LF!				$(this).parent().prepend(copyButton);"
REM set "copyButtonJs=!copyButtonJs!!LF!			});"
REM set "copyButtonJs=!copyButtonJs!!LF!		});"
REM set "copyButtonJs=!copyButtonJs!!LF!^	</script^>"
REM 
REM REM mod_end_2024年6月27日
REM del_end_2024年8月22日_Ver.2.0

:: MarkdownをHTMLに変換
REM mod_start_2024年8月22日
REM pandoc "%inputMarkdown%" -o "%outputHtml%"


:: HTMLファイルをダウンロード
curl https://takeru-server.github.io/markdown-html-converter-assets/template.html -o template.html

pandoc "%inputMarkdown%" --highlight-style=zenburn --standalone --template template.html -o "%outputHtml%" -M title="%~n1"

:: 変換後は削除する
del template.html
REM mod_end_2024年8月22日

:: pandoc オプション参考：https://dev.classmethod.jp/articles/pandoc-markdown2html/
:: 「--toc --toc-depth=2」は、「--toc」は目次の生成で、「--toc-depth=NUMBER」は目次をH1～H3のどれで作成するかを数字を入力する

:: ソースコードの色を変える「--highlight-style」オプションには、pygments, tango, kate, monochrome, espresso, zenburn, haddockなどのスタイルを指定できる	add_2024年8月22日



REM del_start_2024年8月22日_Ver.2.0
REM :: HTMLにヘッダーとフッターを追加
REM (
REM 	echo ^<!DOCTYPE html^>
REM 	echo ^<html xmlns=^"http://www.w3.org/1999/xhtml^" lang=^"ja^" xml:lang=^"ja^"^>
REM 	echo ^<head^>
REM 	echo 	^<meta charset=^"utf-8^" /^>
REM 	echo 	^<title^>%~n1^</title^>
REM 	echo 	^<link rel=^"stylesheet^" href=^"!cssPath!^"^>
REM 	echo 	^<script src=^"!jsPath!^"^>^</script^>
REM 	echo 	^<script src=^"!jqueryCdn!^"^>^</script^>
REM 	echo 	!copyButtonJs!
REM 	echo ^</head^>
REM 	echo ^<body^>
REM 	echo 	^<header id=^"title-block-header"^>
REM 	echo 		^<h1 class=^"title"^>%~n1</h1>
REM 	echo 	^</header^>
REM ) > "%outputHtml%.tmp"
REM type "%outputHtml%" >> "%outputHtml%.tmp"
REM echo ^</body^> >> "%outputHtml%.tmp"
REM echo ^</html^> >> "%outputHtml%.tmp"
REM 
REM :: 一時ファイルをリネーム
REM move /Y "%outputHtml%.tmp" "%outputHtml%"
REM 
REM :: prettierでHTMLを自動整形する
REM prettier --write "%outputHtml%"
REM del_end_2024年8月22日_Ver.2.0

echo.
echo 変換が完了しました: "%outputHtml%"
pause

endlocal