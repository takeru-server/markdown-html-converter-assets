@echo off
setlocal EnableDelayedExpansion

:: コマンドプロンプトの文字コードをUTF-8に変更
chcp 65001

set "inputMarkdown=%~1"
set "outputHtml=%~dpn1.html"
set "tempFile=%~dpn1.tmp.html"

:: --self-contained を --embed-resources --standalone に変更
:: タイトルを動的に取得
pandoc -f markdown -t html5 "%inputMarkdown%" -s --embed-resources --standalone -c "%~dp0github-markdown.css" -o "%outputHtml%" --metadata title="%~n1"

:: 絶対パスを取得
set "cssPath=%~dp0gemini-style.css"
set "jsPath=%~dp0copy-button.js"

:: jQuery CDNのURL
set "jqueryCdn=https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"

:: コピーボタンを追加するJavaScriptコード (改行とインデントを追加)
REM mod_start_2024年6月27日
REM set "copyButtonJs="
REM set "copyButtonJs=!copyButtonJs!^<script^>"
REM set "copyButtonJs=!copyButtonJs!$(document).ready(function() {"
REM set "copyButtonJs=!copyButtonJs!  $('pre code.sourceCode').each(function() {"
REM set "copyButtonJs=!copyButtonJs!    const copyButton = $('^<button class=\"copy-button\"^>コピー^</button^>');"
REM set "copyButtonJs=!copyButtonJs!    copyButton.on('click', function() {"
REM set "copyButtonJs=!copyButtonJs!      const codeBlock = $(this).parent().find('code');"
REM set "copyButtonJs=!copyButtonJs!      const tempTextArea = $('^<textarea^>');"
REM set "copyButtonJs=!copyButtonJs!      $('body').append(tempTextArea);"
REM set "copyButtonJs=!copyButtonJs!      tempTextArea.val(codeBlock.text()).select();"
REM set "copyButtonJs=!copyButtonJs!      document.execCommand('copy');"
REM set "copyButtonJs=!copyButtonJs!      tempTextArea.remove();"
REM set "copyButtonJs=!copyButtonJs!      $(this).text('コピー完了！');"
REM set "copyButtonJs=!copyButtonJs!      setTimeout(function() {"
REM set "copyButtonJs=!copyButtonJs!        copyButton.text('コピー');"
REM set "copyButtonJs=!copyButtonJs!      }, 1500);"
REM set "copyButtonJs=!copyButtonJs!    });"
REM set "copyButtonJs=!copyButtonJs!    $(this).parent().prepend(copyButton);"
REM set "copyButtonJs=!copyButtonJs!  });"
REM set "copyButtonJs=!copyButtonJs!});"
REM set "copyButtonJs=!copyButtonJs!^</script^>"


REM 改行コマンドを変数に格納する	参考：https://it-engineer-info.com/language/batch/6481/
SET LF=^



REM インデントを付けて出力するように修正
set "copyButtonJs="
set "copyButtonJs=!copyButtonJs!!LF!^	<script^>"
set "copyButtonJs=!copyButtonJs!!LF!		$(document).ready(function() {"
set "copyButtonJs=!copyButtonJs!!LF!			$('pre code.sourceCode').each(function() {"
set "copyButtonJs=!copyButtonJs!!LF!				const copyButton = $('^<button class="copy-button"^>コピー^</button^>');"
set "copyButtonJs=!copyButtonJs!!LF!				copyButton.on('click', function() {"
set "copyButtonJs=!copyButtonJs!!LF!					const codeBlock = $(this).parent().find('code');"
set "copyButtonJs=!copyButtonJs!!LF!					const tempTextArea = $('^<textarea^>');"
set "copyButtonJs=!copyButtonJs!!LF!					$('body').append(tempTextArea);"
set "copyButtonJs=!copyButtonJs!!LF!					tempTextArea.val(codeBlock.text()).select();"
set "copyButtonJs=!copyButtonJs!!LF!					document.execCommand('copy');"
set "copyButtonJs=!copyButtonJs!!LF!					tempTextArea.remove();"
set "copyButtonJs=!copyButtonJs!!LF!					$(this).text('コピー完了！');"
set "copyButtonJs=!copyButtonJs!!LF!					setTimeout(function() {"
set "copyButtonJs=!copyButtonJs!!LF!						copyButton.text('コピー');"
set "copyButtonJs=!copyButtonJs!!LF!					}, 1500);"
set "copyButtonJs=!copyButtonJs!!LF!				});"
set "copyButtonJs=!copyButtonJs!!LF!				$(this).parent().prepend(copyButton);"
set "copyButtonJs=!copyButtonJs!!LF!			});"
set "copyButtonJs=!copyButtonJs!!LF!		});"
set "copyButtonJs=!copyButtonJs!!LF!^	</script^>"

REM mod_end_2024年6月27日

:: MarkdownをHTMLに変換
pandoc "%inputMarkdown%" -o "%outputHtml%"
:: pandoc オプション参考：https://dev.classmethod.jp/articles/pandoc-markdown2html/
:: 「--toc --toc-depth=2」は、「--toc」は目次の生成で、「--toc-depth=NUMBER」は目次をH1～H3のどれで作成するかを数字を入力する

:: HTMLにヘッダーとフッターを追加
(
	echo ^<!DOCTYPE html^>
	echo ^<html xmlns=^"http://www.w3.org/1999/xhtml^" lang=^"ja^" xml:lang=^"ja^"^>
	echo ^<head^>
	echo 	^<meta charset=^"utf-8^" /^>
	echo 	^<title^>%~n1^</title^>
	echo 	^<link rel=^"stylesheet^" href=^"!cssPath!^"^>
	echo 	^<script src=^"!jsPath!^"^>^</script^>
	echo 	^<script src=^"!jqueryCdn!^"^>^</script^>
	echo 	!copyButtonJs!
	echo ^</head^>
	echo ^<body^>
	echo 	^<header id=^"title-block-header"^>
	echo 		^<h1 class=^"title"^>%~n1</h1>
	echo 	^</header^>
) > "%outputHtml%.tmp"
type "%outputHtml%" >> "%outputHtml%.tmp"
echo ^</body^> >> "%outputHtml%.tmp"
echo ^</html^> >> "%outputHtml%.tmp"

:: 一時ファイルをリネーム
move /Y "%outputHtml%.tmp" "%outputHtml%"

:: prettierでHTMLを自動整形する
prettier --write "%outputHtml%"

echo.
echo 変換が完了しました: "%outputHtml%"
pause

endlocal