@echo off
setlocal EnableDelayedExpansion

:: コマンドプロンプトの文字コードをUTF-8に変更
chcp 65001

set "inputMarkdown=%~1"
set "outputHtml=%~dpn1.html"

:: CSSのURL
set "geminiCSS=https://takeru-server.github.io/markdown-html-converter-assets/css/gemini-style.css"

:: copyButton.jsへのURL
set "jqueryJS=https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"
set "copyButtonJS=https://takeru-server.github.io/markdown-html-converter-assets/js/copy-button.js"
set "copyCodeButtonJS=https://takeru-server.github.io/markdown-html-converter-assets/js/copy-code-button.js"

:: ソースコードの色を変える「--highlight-style」オプションには、pygments, tango, kate, monochrome, espresso, zenburn, haddockなどのスタイルを指定できる	参考：https://qiita.com/kaityo256/items/01176b3c463ba45166f9

:: MarkdownをHTMLに変換 (一時ファイルにリダイレクト)
pandoc "%inputMarkdown%" ^
    --highlight-style=pygments ^
    --standalone ^
    -M title="%~n1" ^
    --css "%geminiCSS%" > "%outputHtml%.tmp"

REM ↑テンプレート「https://raw.githubusercontent.com/ryangrose/easy-pandoc-templates/master/html/elegant_bootstrap_menu.html」を利用してもいいかも	参考：https://dev.classmethod.jp/articles/pandoc-markdown2html/#HTML%25E3%2583%2595%25E3%2582%25A1%25E3%2582%25A4%25E3%2583%25AB%25E3%2581%25A8%25E3%2581%2597%25E3%2581%25A6%25E3%2581%25AE%25E5%2587%25BA%25E5%258A%259B

:: jQueryとcopyButton.jsの<script>タグを追記 (</body>の直前に挿入)
(
  for /f "delims=" %%a in (%outputHtml%.tmp) do (
    if "%%a"=="</body>" (
REM      echo ^<script src="https://code.jquery.com/jquery-3.7.1.min.js"^>^</script^>
      echo ^<script src="%jqueryJS%"^>^</script^>
      echo ^<script src="%copyButtonJS%"^>^</script^>
      echo ^<script src="%copyCodeButtonJS%"^>^</script^>
    )
    echo %%a 
  )
) > "%outputHtml%"

:: 一時ファイルを削除
del "%outputHtml%.tmp"

echo.
echo 変換が完了しました: "%outputHtml%"
pause

endlocal