module.exports = {
	// インデントサイズを設定します（デフォルトは4スペース）。
	"indent_size": 4,

	// インデントに使う文字を設定します。スペース(" ")またはタブ("\t")を指定できます。
	"indent_char": " ",

	// 連続して許可される改行の最大数を設定します（0は無制限）。
	"max_preserve_newlines": 10,

	// 改行を維持するかどうかを設定します。
	"preserve_newlines": true,

	// <script>タグの内容のインデント方法を設定します。
	// "keep" はそのままにする、"separate" は改行、"normal" はインデントを適用する。
	"indent_scripts": "normal",

	// 波括弧スタイルを設定します。選択肢は "collapse" (標準)、"expand"、"end-expand"、"none" です。
	"brace_style": "collapse",

	// HTMLの内部をインデントするかどうかを設定します（falseにすると<pre>なども含む）。
	"indent_inner_html": false,

	// この長さを超える行は折り返されます。0は無効化します。
	"wrap_line_length": 0,

	// 属性を折り返す条件を設定します。
	// "auto"（デフォルト）、"force"、"force-aligned"、"force-expand-multiline"
	"wrap_attributes": "auto",

	// 属性のインデントサイズを設定します。
	"wrap_attributes_indent_size": 4,

	// ファイルの末尾に改行を追加するかどうかを設定します。
	"end_with_newline": true,
	
	// ラインの長さをどこで折り返すか（0で無効）
	wrap_line_length: 0,
	
	// HTMLの内部もインデントするかどうか
	indent_inner_html: false,
	
	// コンマを先頭に持ってくるスタイルにするかどうか
	comma_first: false,
	
	// E4X (XML extension) をサポートするかどうか
	e4x: false,
	
	// 空行もインデントするかどうか
	indent_empty_lines: false,
	
	// インデントの初期レベル
	indent_level: 0
};