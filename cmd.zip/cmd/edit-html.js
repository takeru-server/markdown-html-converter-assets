const fs = require('fs').promises; // promises を使用
const jsdom = require('jsdom');
const { JSDOM } = jsdom;

// コマンドライン引数からHTMLファイルのパスを取得
const htmlFilePath = process.argv[2];
const cssFilePath = 'gemini-style.css';
// highlight.js のCSSのURL (テーマは必要に応じて変更)
const highlightCssUrl = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.8.0/styles/default.min.css';

// メイン処理を async 関数で定義
async function main() {
	try {
		// HTMLファイルを読み込む
		const data = await fs.readFile(htmlFilePath, 'utf-8');

		// HTMLをDOMとして解析
		const dom = new JSDOM(data);
		const document = dom.window.document;

		// <link> タグを作成 (gemini-style.css)
		const linkTag = document.createElement('link');
		linkTag.rel = 'stylesheet';
		linkTag.href = cssFilePath;

		// <link> タグを作成 (highlight.js)
		const highlightLinkTag = document.createElement('link');
		highlightLinkTag.rel = 'stylesheet';
		highlightLinkTag.href = highlightCssUrl;

		// <script> タグを作成 (不要になったのでコメントアウト)
		// const scriptTag = document.createElement('script');
		// scriptTag.src = jsFilePath;

		// <head> タグ内に <link> タグを挿入
		const headTag = document.querySelector('head');
		headTag.appendChild(linkTag);
		headTag.appendChild(highlightLinkTag); 

		// clipboardy パッケージを動的に読み込む
		const clipboardy = await import('clipboardy');

		// すべてのコードブロックにコピーボタンを追加
		const codeBlocks = document.querySelectorAll('pre code.sourceCode');
		codeBlocks.forEach((codeBlock) => {
			// コピーボタンを作成
			const copyButton = document.createElement('button');
			copyButton.classList.add('copy-button');
			copyButton.textContent = 'コピー';

			// コピーボタンのクリックイベントリスナーを追加
			copyButton.addEventListener('click', () => {
				// クリップボードにコードをコピー (clipboardyを使用)
				clipboardy.default.writeSync(codeBlock.innerHTML); // clipboardy.default.writeSync() を使用

				copyButton.textContent = 'コピー完了!';
				setTimeout(() => {
					copyButton.textContent = 'コピー';
				}, 1500);
			});

			// コードブロックの前にコピーボタンを追加
			codeBlock.parentNode.insertBefore(copyButton, codeBlock);
		});

		// 修正後のHTMLをファイルに書き込む
		const modifiedHtml = dom.serialize();
		await fs.writeFile(htmlFilePath, modifiedHtml, 'utf-8');

		console.log('HTMLファイルを修正しました:', htmlFilePath);
	} catch (err) {
		console.error('エラーが発生しました:', err);
	}
}

// main 関数を実行
main();