function Str(el)
  -- 不要な \n を削除
  el.text = el.text:gsub("\\n", "")
  return el
end

function CodeBlock(el)
  if el.classes:includes('sourceCode') then
    -- Pandocが生成するsourceCodeクラスを持つコードブロックにgemini-codeクラスを追加
    table.insert(el.classes, 'gemini-code')
  end
  return el
end