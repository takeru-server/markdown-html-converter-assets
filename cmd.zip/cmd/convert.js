const showdown = require('showdown');
const hljs = require('highlight.js');
// SQL言語モジュールを読み込む (パッケージ名を修正)
const sql = require('highlightjs-sql'); 
hljs.registerLanguage('sql', sql);

// MarkdownをHTMLに変換
function convertMarkdown(markdown) {
	const converter = new showdown.Converter({
		extensions: [
			{
				type: 'output',
				filter: (text, converter, options) => {
					// highlight.jsを使ってコードブロックをハイライト
					return text.replace(/<pre><code\s*(?:class="([^"]*)")?>([\s\S]*?)<\/code><\/pre>/g, (match, lang, code) => {
						if (lang) {
							return `<pre><code class="${lang} hljs">${hljs.highlight(code, { language: lang }).value}</code></pre>`;
						} else {
							return `<pre><code class="hljs">${hljs.highlightAuto(code).value}</code></pre>`;
						}
					});
				},
			},
		],
	});
	return converter.makeHtml(markdown);
}

// HTMLにCSSとJavaScriptを追加
function addResources(html, cssPath, jsPath) {
	const headerTag = '<header id="title-block-header">';
	const newHeader = `${headerTag}
	<link rel="stylesheet" href="${cssPath}">
	<script src="${jsPath}"></script>`;
	return html.replace(headerTag, newHeader);
}

// メイン処理
const markdownFilePath = process.argv[2]; // コマンドライン引数からMarkdownファイルのパスを取得
const cssFilePath = 'gemini-style.css';
const jsFilePath = 'copy-button.js';

const fs = require('fs');
fs.readFile(markdownFilePath, 'utf-8', (err, data) => {
	if (err) {
		console.error('ファイルの読み込みに失敗しました:', err);
		return;
	}

	const html = convertMarkdown(data);
	const htmlWithResources = addResources(html, cssFilePath, jsFilePath);
	const outputHtmlPath = markdownFilePath.replace(/\.md$/, '.html');

	fs.writeFile(outputHtmlPath, htmlWithResources, 'utf-8', (err) => {
		if (err) {
			console.error('ファイルの書き込みに失敗しました:', err);
			return;
		}

		console.log('HTMLファイルに変換しました:', outputHtmlPath);
	});
});