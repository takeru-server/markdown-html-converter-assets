## oce_sp_受注番号一括削除_SEL ストアドプロシージャ SQL文分析結果

以下、ストアドプロシージャ oce_sp_受注番号一括削除_SEL 内のSQL文について、分析結果を記述します。

### 1. ストアドプロシージャ名の取得

```sql
SELECT @strSpName = ISNULL(name, '') FROM dbo.sysobjects WHERE id = @PROCID
```

| 項目 | 内容 |
|---|---|
| 対象 | dbo.sysobjects |
| 操作 | 参照 ○ |
| レコード選択条件 | id = 実行中のストアドプロシージャID |


### 2. 受注入力済みデータ件数確認

```sql
SELECT @iROWEXIST = CAST(ISNULL(COUNT(*), 0) as int) FROM T_受注 WHERE T_受注.受注部署コード = @str部署 AND T_受注.受注番号 = @str受注番号
```

| 項目 | 内容 |
|---|---|
| 対象 | T_受注 |
| 操作 | 参照 ○ |
| レコード選択条件 | 受注部署コード = @str部署 AND 受注番号 = @str受注番号 |

### 3. ワーククリア（親）

```sql
DELETE FROM W_受注番号一括削除 WHERE sessionId = @isessionId
```

| 項目 | 内容 |
|---|---|
| 対象 | W_受注番号一括削除 |
| 操作 | 削除 ○ |
| レコード選択条件 | sessionId = @isessionId |

### 4. ワーククリア（子）

```sql
DELETE FROM W_受注番号一括削除SUB WHERE sessionId = @isessionId
```

| 項目 | 内容 |
|---|---|
| 対象 | W_受注番号一括削除SUB |
| 操作 | 削除 ○ |
| レコード選択条件 | sessionId = @isessionId |


### 5. ワークへ展開（親）

```sql
INSERT INTO  W_受注番号一括削除 (受注番号, 振替手配番号, 依頼先注文番号, 受注部署コード, 受注従業員コード, 取引先コード, 取引先名, 事業所コード, 事業所名, 請求先コード, 請求先名, 件名, 受注合計額, 売上合計額, 入力方式区分, 修正ID, 修正日時, sessionId) SELECT T_受注.受注番号, T_受注.振替手配番号, T_受注.依頼先注文番号, T_受注.受注部署コード, T_受注.受注従業員コード, T_受注.取引先コード, T_受注.取引先名, T_受注.事業所コード, T_受注.事業所名, T_受注.請求先コード, T_受注.請求先名, T_受注.件名, T_受注.受注合計額, ISNULL((select T_売上.売上合計額 from T_売上 Where T_売上.受注番号 = T_受注.受注番号),0) as 売上合計額, T_受注.入力方式区分, T_受注.修正ID, T_受注.修正日時, @isessionId AS sessionId FROM T_受注 WHERE T_受注.受注番号 = @str受注番号
```

| 項目 | 内容 |
|---|---|
| 対象 | W_受注番号一括削除 |
| 操作 | 追加 ○ |
| レコード選択条件 | T_受注 から 受注番号 = @str受注番号 のデータを選択して挿入 |

- 備考: T_売上 から 売上合計額 を参照


### 6. ワークへ展開（子） - 受注+仕入(+支払+売上)

```sql
-- 省略: 長いため SQL本文は省略
-- 対象テーブルと結合条件のみ記述
INSERT INTO W_受注番号一括削除SUB (...) 
SELECT ... 
FROM T_受注SUB
INNER JOIN T_受注 ON T_受注SUB.受注番号 = T_受注.受注番号 
INNER JOIN T_仕入SUB ON T_受注SUB.受注手配番号 = T_仕入SUB.受注手配番号
INNER JOIN T_仕入 ON T_仕入.仕入番号 = T_仕入SUB.仕入番号
WHERE T_受注SUB.受注番号 = @str受注番号
```

| 項目 | 内容 |
|---|---|
| 対象 | W_受注番号一括削除SUB |
| 操作 | 追加 ○ |
| レコード選択条件 |  T_受注SUB, T_受注, T_仕入SUB, T_仕入 を結合し、T_受注SUB.受注番号 = @str受注番号 のデータを選択して挿入 |

- 備考: T_支払, T_支払SUB, T_売上SUB から 各項目を参照


### 7. ワークへ展開（子） - 受注+振替(+売上)

```sql
-- 省略: 長いため SQL本文は省略
-- 対象テーブルと結合条件のみ記述
INSERT INTO W_受注番号一括削除SUB (...) 
SELECT ... 
FROM T_受注SUB
INNER JOIN T_受注 ON T_受注SUB.受注番号 = T_受注.受注番号 
INNER JOIN T_受注振替SUB ON T_受注SUB.受注手配番号 = T_受注振替SUB.受注手配番号
INNER JOIN T_受注振替 ON T_受注振替.振替番号 = T_受注振替SUB.振替番号
WHERE T_受注SUB.受注番号 = @str受注番号
```

| 項目 | 内容 |
|---|---|
| 対象 | W_受注番号一括削除SUB |
| 操作 | 追加 ○ |
| レコード選択条件 | T_受注SUB, T_受注, T_受注振替, T_受注振替SUB を結合し、T_受注SUB.受注番号 = @str受注番号 のデータを選択して挿入 |

- 備考: T_売上SUB から 各項目を参照


### 8. ワークへ展開（子） - 受注のみ

```sql
-- 省略: 長いため SQL本文は省略
-- 対象テーブルと結合条件のみ記述
INSERT INTO W_受注番号一括削除SUB (...) 
SELECT ... 
FROM T_受注SUB
INNER JOIN T_受注 ON T_受注SUB.受注番号 = T_受注.受注番号 
WHERE T_受注SUB.受注番号 = @str受注番号
AND NOT EXISTS (
    SELECT W_受注番号一括削除SUB.受注手配番号
    FROM W_受注番号一括削除SUB
    WHERE W_受注番号一括削除SUB.受注手配番号 = T_受注SUB.受注手配番号
    AND W_受注番号一括削除SUB.sessionId = @isessionId
    GROUP BY W_受注番号一括削除SUB.受注手配番号
)
```

| 項目 | 内容 |
|---|---|
| 対象 | W_受注番号一括削除SUB |
| 操作 | 追加 ○ |
| レコード選択条件 | T_受注SUB, T_受注 を結合し、T_受注SUB.受注番号 = @str受注番号 のデータのうち、W_受注番号一括削除SUB に存在しない受注手配番号のデータを選択して挿入 |

- 備考: T_売上SUB から 各項目を参照


### 9. ログ書き出し

```sql
INSERT INTO L_LOG VALUES ('T_受注', @str処理, '受注番号' + @str受注番号, @iROWCOUNT, @strSpName + ' SPID=' + CAST(@@SPID AS nvarchar), @iuserId, CONVERT(CHAR(23),GETDATE(),121))
```

| 項目 | 内容 |
|---|---|
| 対象 | L_LOG |
| 操作 | 追加 ○ |
| レコード選択条件 | なし (固定値と変数の挿入) |


## まとめ

このストアドプロシージャは、「T_受注」テーブルを起点に関連するテーブルからデータを取得し、「W_受注番号一括削除」「W_受注番号一括削除SUB」テーブルに展開する処理を行っています。
処理内容は複雑ですが、1つ1つのSQL文を分析することで、どのようなデータが参照・更新・削除されているかを把握することができます。