## Oocs2024.Sources.Common.CommonFunction クラスの概要

このクラスは、OCSシステムで共通的に使用される関数をまとめた静的クラスです。主に文字列操作、数値チェック、日付チェック、ログ出力、メッセージ表示、区分マスタ操作、CSV入出力、自動採番、コントロール操作、DB操作、ユーティリティ関数を提供します。

### メソッドごとの概要

#### 文字列操作・チェック

- **IsNumeric(string stTarget)**: 文字列が数値かどうかを判定します。
- **IsNumeric(object oTarget)**: オブジェクトが数値かどうかを判定します。
- **CountChar(string CheckString, char CheckChar)**: 文字列内の指定文字の出現回数をカウントします。
- **IsKanaOnly(string CheckString)**: 文字列が全角カタカナのみかどうかを判定します。
- **IsAlpaCharacter(string CheckString)**: 文字列が英字のみかどうかを判定します。
- **IsNumericOrg(string CheckString)**: 文字列が数値のみかどうかを判定します。(カンマ、ピリオドを含む)
- **IsNumericAlphaOrg(string CheckString)**: 文字列が数値、英字、半角記号のみかどうかを判定します。
- **MaxLength(string CheckString, int CheckMaxLength, int CheckDecMaxLength)**: 文字列が指定された桁数以下かどうかを判定します。(小数点を含む)
- **MaxLength(string CheckString, int CheckMaxLength)**: 文字列が指定された桁数以下かどうかを判定します。(整数のみ)
- **MaxDate(string CheckString, string CheckMaxDate)**: 文字列が指定された日付以前かどうかを判定します。
- **MinDate(string CheckString, string CheckMinDate)**: 文字列が指定された日付以降かどうかを判定します。
- **IsDate(string CheckString)**: 文字列が日付型式かどうかを判定します。
- **IsDate(string CheckString, string FormatString)**: 文字列が指定された日付型式かどうかを判定します。
- **textToDatetime(String pText, String FormatString)**: 文字列を指定された日付型式でDateTime型に変換します。
- **IsEmpty(string CheckString)**: 文字列が空文字かどうかを判定します。
- **IsEmptyOrSpace(string CheckString)**: 文字列が空文字またはスペースのみかどうかを判定します。
- **IsWide(string CheckString)**: 文字列が全角のみかどうかを判定します。
- **IsPostNo(string CheckString)**: 文字列が郵便番号型式かどうかを判定します。
- **IsNarrow(string CheckString)**: 文字列が半角のみかどうかを判定します。
- **IsNarrowNumericAlphaOrg(string CheckString)**: 文字列が半角英数字のみかどうかを判定します。
- **MinValue(string CheckString, double CheckMinValue)**: 数値が指定された最小値以上かどうかを判定します。
- **MaxValue(string CheckString, double CheckMaxValue)**: 数値が指定された最大値以下かどうかを判定します。
- **GetStringBytes(string stTarget)**: 文字列のバイト数を取得します。
- **ToWide(string strInputString)**: 文字列を全角に変換します。
- **ReplaceToValidFileName(string strInputString)**: ファイル名に使用できない文字列を"_"に置き換えます。
- **ReplaceLf(string targetValue, string replaceString)**: "\n" を指定された文字列に置き換えます。
- **ConvertString(object targetOBJ, string replaceString)**: DBNull, Null を指定された文字列に置き換えます。
- **Add改行(string strBefore, int WidthMax, int RowMax)**: 文字列の一定幅ごとに改行コードを追加します。
- **IsKanaHalfOnly(string CheckString)**: 文字列が半角カタカナのみかどうかを判定します。

#### 数値操作

- **ToRoundUp(decimal dValue, int iDigits)**: 指定した精度の数値に切り上げます。
- **ToRoundDown(decimal dValue, int iDigits)**: 指定した精度の数値に切り捨てます。
- **ToHalfAdjust(double dValue, int iDigits)**: 指定した精度の数値に四捨五入します。
- **ToHalfAdjust(decimal decValue, int iDigits)**: 指定した精度の数値に四捨五入します。(Decimal版)

#### ログ出力・メッセージ表示

- **WriteLog(string formID, string messageID, params String[] insertMessage)**: メッセージテーブルから取得したメッセージをログDBに出力します。(標準ログ出力)
- **WriteLog(string formID, string message)**: ログをDBに出力します。(標準ログ出力)
- **WriteErrorLog(string message)**: エラーログをログテキストファイルに出力します。(エラーログ出力)
- **WriteErrorLog(Exception e)**: 例外オブジェクトのエラーログをログテキストファイルに出力します。(エラーログ出力)
- **EditMessage(string messageID, params string[] insertMessage)**: メッセージテーブルからmessageIDをキーにメッセージ本文を取得し、挿入句を編集します。
- **MessageDialog(string formID, string messageID, params String[] insertMessage)**: メッセージを標準ダイアログで表示します。(メッセージ本文は標準ログ出力でログ出力)
- **MessageDialogOkCancel(string formID, string messageID, MessageBoxDefaultButton defaultButton, params string[] insertMessage)**: OK,CANCELボタン付きメッセージを標準ダイアログで表示します。(メッセージ本文は標準ログ出力でログ出力)
- **MessageDialogOkCancel(string formID, string messageID, params string[] insertMessage)**: OK,CANCELボタン付きメッセージを標準ダイアログで表示します。(メッセージ本文は標準ログ出力でログ出力)

#### 区分マスタ操作

- **GetGrouping(string workID, string groupingID, string groupingCD)**: MCmn区分テーブルから値を取得します。
- **GetCodeValueTable(string categoryID, string codeID)**: 引数で指定された条件で区分マスタを取得し、DataTableで返します。
- **GetCodeValueTable(string categoryID, string codeID, bool bolMaintenance)**: 引数で指定された条件で区分マスタを取得し、DataTableで返します。(メンテナンス可能かどうかを指定)
- **GetCodeValueTableColumnAll(string categoryID, string codeID)**: 引数で指定された条件で区分マスタを取得し、DataTableで返します。(値文字、値日付、値数値をすべて取得)
- **SetCodeValueToCmb(ComboBox cmbTarget, string categoryID, string codeID)**: コンボボックスに区分のリストを設定します。
- **SetTableToCmb(ComboBox cmbTarget, string strSelectSQL, string strDisplayMemberFieldName, string strValueMemberFieldName)**: 引数で指定されたSQLの結果をコンボボックスに設定します。
- **SetTableToCmb(ComboBox cmbTarget, string strSelectSQL, string strDisplayMemberFieldName, string strValueMemberFieldName, params Object[] args)**: 引数で指定されたSQLの結果をコンボボックスに設定します。(パラメータあり)
- **GetCodeValue(string categoryID, string codeID, string codeCD, string columnName)**: MCmn区分テーブルから値を取得します。(カラム名指定版)
- **IsFurigana(string CheckString)**: 区分を見てフリガナをチェックします。
- **IsNotDelMenu(string CheckString)**: 区分を見てメニュー管理系かチェックします。

#### CSV入出力

- **CheckOutputFileStatus(string strCheckFilePath, out string strMessageCode)**: 指定された出力用ファイルをOPENしエラーを確認します。
- **OutputCSV(DataTable dtbInputDataTable, string strOutputFilePath)**: 入力データを出力ファイル名で指定されたファイルにCSV型式で出力します。
- **OutputCSV_UTF8(DataTable dtbInputDataTable, string strOutputFilePath)**: 入力データを出力ファイル名で指定されたファイルにCSV型式で出力します。(UTF-8 BOM付き)
- **OutputCharacterSeparatedValues(DataTable dtbInputDataTable, string strOutputFilePath, string strSeparater, string strDelimiter)**: 入力データを出力ファイル名で指定されたファイルに出力します。(区切り文字、括り文字を指定)
- **OutputCharacterSeparatedValues(DataTable dtbInputDataTable, string strOutputFilePath, string strSeparater, string strDelimiter, string strEOL, string strTextEncoding)**: 入力データを出力ファイル名で指定されたファイルに出力します。(区切り文字、括り文字、改行コード、文字コードを指定)
- **CSVObjectToArray(string CSVLineData)**: CSV型式の1行のデータをobjectの配列に分解します。
- **CSVStringToArray(string CSVLineData)**: CSV型式の1行のデータを文字列の配列に分解します。
- **CSVStringToArray(string CSVLineData, String strSeparater, String strDelimiter)**: CSV型式の1行のデータを文字列の配列に分解します。(区切り文字、括り文字を指定)
- **GetFileLineCount(string FileName)**: ファイルの行数を調査します。

#### 自動採番

- **GetNextValue(string strKey, string strSubKey)**: KeyID,SubKeyIDで指定されたコードの自動採番を行います。
- **GetNextValue(string strKey, string strSubKey, SqlTransaction pSqlTransaction)**: KeyID,SubKeyIDで指定されたコードの自動採番を行います。(トランザクションを指定)

#### コントロール操作

- **SearchNextControl(Form thisForm)**: 現在アクティブなコントロールから次にTab移動が可能なオブジェクトを検索します。
- **FindControl(Control hParent, string stName)**: 指定したコントロール内に含まれるコントロールを指定した名前で検索します。
- **getControlList(Control hParent, String nest)**: コントロールに含まれる子コントロールの一覧を出力します。(設計書作成、デバッグ用)
- **SetPrinterListToCmb(CustomComboBox cmbPrinterList, string defaultPrinterName)**: コンボボックスにコンピュータにインストールされているプリンタのリストを取得して代入します。
- **SetPaperListToCmb(CustomComboBox cmbPaperList, String printerName, String paperName, String defaultPaperName)**: 用紙サイズ一覧コンボボックスの設定を行います。
- **GetPaperList(String strPrinterName)**: プリンタに定義されている用紙サイズの一覧を取得します。
- **GetPaperSize(string strPrinterName, string strPaperName)**: クリスタルレポート用の用紙サイズを取得します。
- **SaveDefaultPrinterName(string program_id, string printername)**: システム上でのデフォルトプリンタ名を格納します。
- **LoadDefaultPrinterName(string program_id)**: システム上でのデフォルトプリンタ名を取得します。
- **カレンダーボタン共通(Form frm呼出元, CustomTextBox ターゲット)**: カレンダーボタンの処理を共通化します。
- **カレンダーフォーム呼出(Form frm呼出元, string str元日付)**: カレンダーフォームの表示を行います。

#### DB操作

- **NullToString(object value, string nullResultString)**: オブジェクトがDBNULLなら、nullResultStringを戻します。DBNULLでないならStringに変換して戻します。
- **NullToObject(object value, string nullResultObject)**: オブジェクトがDBNULLなら、nullResultObjectを戻します。DBNULLでないならobjectのまま戻します。
- **ToDBNullOrValue(object value)**: DB登録時オブジェクトがnull,""ならDBNullを返します。違うなら元の値を返します。
- **GetColumnType(string tableName, string ColumnName)**: 引数で指定したテーブル名、列名の列の属性情報を取得します。
- **GetColumnType(string tableName, string ColumnName, SqlTransaction pSqlTransaction)**: 引数で指定したテーブル名、列名の列の属性情報を取得します。(トランザクションを指定)
- **GetDecimalMaxValue(string tableName, string ColumnName, SqlTransaction pSqlTransaction)**: DBのDeciml型のフィールドに入力可能な最大値を取得します。
- **日付有効チェック(string str対象日付YYYYMMDD)**: 日付の有効チェックを行います。

#### ユーティリティ関数

- **GetSpecialFolderList()**: システムの特別なフォルダーへのディレクトリパスのリストをEnvironment.SpecialFolderから取得します。
- **DecodeSpecialFolder(string targetPath)**: targetPathに含まれる特殊フォルダ名を、その特殊フォルダの実際のPathに置換します。
- **GetTaxRate(DateTime date)**: 日付から税率を求めます。
- **GetTaxRate(DateTime date, SqlTransaction pSqlTransaction)**: 日付から税率を求めます。(トランザクションを指定)
- **GetLastDate(DateTime targetMonth)**: 引数で指定された月の最終日を取得します。
- **GetFirstDate(DateTime targetMonth)**: 引数で指定された月の1日を取得します。
- **chg和暦To西暦(string str和暦)**: 和暦表示のデータを西暦に戻します。
- **get和暦年月日(DateTime pDate, string pFormat, string pDelimiter, string pFrontStuffing)**: スカラ関数を実行し元号マスタを参照して和暦変換した値を取得します。
- **get和暦年月日_年号漢字１文字版(string pDate, string pFormat, string pDelimiter, string pFrontStuffing)**: スカラ関数を実行し元号マスタを参照して和暦変換した値を取得します。(get和暦年月日のpFormatに「3 :昭55」を追加した版)
- **get和暦(DateTime pDate, string pFormat, string pDelimiter, string pFrontStuffing, string pYearOnly)**: スカラ関数を実行し元号マスタを参照して和暦変換した値を取得します。(get和暦年月日の引数にpYearOnly（年月のみ・年のみを返す）を追加した版)
- **getBarCode住所(string p郵便番号, string p住所)**: カスタマバーコード用の値を作成します。
- **除票者判定(string str宛名番号)**: 現在、除票者か判定を行います。
- **除票者判定(string str宛名番号, string str除票種類)**: 現在、除票者か判定を行います。除票の種類を指定し、除票者ならその日付を返す。
- **生保判定(string str宛名番号)**: 現在、生保対象者かどうか判定します。
- **保護者判定(string str宛名番号)**: 保護者登録された保護者宛名番号を返します。

**注意**: 各メソッドの詳細な仕様や使用方法については、コード内のコメントを参照してください。
